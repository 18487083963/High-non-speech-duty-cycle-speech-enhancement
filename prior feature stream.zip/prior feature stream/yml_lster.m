function [voprob1,hz1]=yml_lster(E)
voprob1=zeros(length(E),1);
win=33;
h1=0.2;
len=ceil((length(E)-win)/11+1);
k=0;%
T=1;
i=1;
while(T==1)
    de=E(1+k*win/3:win+k*win/3);
    lster=sum(0.65*mean(de)-sign(de)+1)/(win-1);
    hz1(i)=lster;
    i=i+1;
    if lster>h1
        voprob1(1+k*win/3:win+k*win/3)=1;
    end
    if win+(k+1)*win*1/3<=length(E)
        k=k+1;
    else
        de=E(1+(k+2)*win/3:end);
        lster=sum(0.65*mean(de)-sign(de)+1)/(win-1);
        hz1(i)=lster;
        T=0;
        if lster>h1
            voprob1(1+(k+2)*win/3:end)=1;
        end
    end
end