import torch
import torch.nn as nn
import torch.nn.functional as F
import math

"""Time Delay Neural Network as mentioned in the 1989 paper by Waibel et al. (Hinton) and the 2015 paper by Peddinti et al. (Povey)"""

class TDNN(nn.Module):
    def __init__(self, context, input_dim, output_dim, full_context = True):
        super(TDNN,self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.check_valid_context(context) #有效范围
        self.kernel_width, context = self.get_kernel_width(context,full_context)  #核宽度
        self.register_buffer('context',torch.LongTensor(context))
        self.full_context = full_context
        stdv = 1./math.sqrt(input_dim)
        self.kernel = nn.Parameter(torch.Tensor(output_dim, input_dim,self.kernel_width).normal_(0,stdv))
        self.bias = nn.Parameter(torch.Tensor(output_dim).normal_(0,stdv))
        # self.cuda_flag = False

    def forward(self,x):
        # Check if parameters are cuda type and change context
        # if type(self.bias.data) == torch.cuda.FloatTensor and self.cuda_flag == False:
        #     self.context = self.context.cuda()
        #     self.cuda_flag = True
        conv_out = self.special_convolution(x, self.kernel, self.context, self.bias)
        return conv_out

    def special_convolution(self, x, kernel, context, bias):
        input_size = x.size()
        assert len(input_size) == 3, 'Input tensor dimensionality is incorrect. Should be a 3D tensor' #断言语句，如果不是，则报错。
        [batch_size,channel,input_sequence_length] = input_size
        # Allocate memory for output
        valid_steps = self.get_valid_steps(self.context, batch_size)  #做延时后的帧数目
        #length=input_sequence_length-self.kernel_width+1
        #xs = torch.zeros(len(valid_steps), kernel.size()[0], input_sequence_length)  #参见函数文档（默认的stride=1）
        device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
        #xs = xs.to(device)
        # Perform the convolution with relevant input frames
        for c, i in enumerate(valid_steps):
            features = torch.index_select(x, 0, context+i)#在指定维度，根据索引号查找
            features=features.view(1,features.size(0),-1)#维度变换
            xs= F.conv1d(features, kernel, bias = bias,padding=1)
            if i==2:
                y=xs
            else:
                y=torch.cat([y,xs],dim=0)
        y = y.to(device)
        return y

    @staticmethod   #统计方法（池化）
    def check_valid_context(context): #检查context是否合理
        # here context is still a list
        assert context[0] <= context[-1], 'Input tensor dimensionality is incorrect. Should be a 3D tensor'

    @staticmethod
    def get_kernel_width(context, full_context):
        if full_context:
            context = range(context[0],context[-1]+1) #确定一个context的范围
        return len(context), context

    @staticmethod
    def get_valid_steps(context, batch_size): #确定给定长度的序列，卷积之后的长度
        start = 0 if context[0] >= 0 else -1*context[0]
        end = batch_size if context[-1] <= 0 else batch_size - context[-1]
        return range(start, end)
