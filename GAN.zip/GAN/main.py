import argparse
import os

import torch
import torch.nn as nn
import h5py
import numpy as np
import pandas as pd
from scipy.io import wavfile
from torch import optim
from torch.autograd import Variable
from torch.utils.data import DataLoader
from tqdm import tqdm #Tqdm是一个快速，可扩展的python进度条，可以在python长循环中添加一个进度提示信息，用户只需要封装任意的迭代器tqdm(iterator)。
import random

#from torch.utils.data.DataLoader import default_collate #torch.utils.data.dataloader import default_collate # 导入默认的拼接方式
from data_preprocess import serialized_train_folder
from data_preprocess import sample_rate
from model import Generator, Discriminator
from Dataset import AudioDataset, emphasis


def my_collate(batch): #DataLoader自定义的拼接方式
    for i, inputs in enumerate(batch):
        for j, inputss in enumerate(inputs):
            if i==0:
                if j==0:
                    train_batch=inputss
                elif j==1:
                    clean=inputss
                else:
                    noisy=inputss
            else:
                if j==0:
                    #train_batch=torch.cat([train_batch,inputss],dim=0)
                    train_batch = torch.cat([train_batch, inputss],dim=0)
                elif j==1:
                    clean=torch.cat([clean,inputss],dim=0)
                else:
                    noisy=torch.cat([noisy,inputss],dim=0)
    return train_batch,clean,noisy
    #'''#

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Train Audio Enhancement')
    parser.add_argument('--batch_size', default=2, type=int, help='train batch size') #一个文件里存放了很多分帧数据即一个batch其实是包含很多数据的
    parser.add_argument('--num_epochs', default=100, type=int, help='train epochs number')
    #device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu") #检查pytorch是否是GPU版本
    device=torch.device("cpu")

    opt = parser.parse_args()
    BATCH_SIZE = opt.batch_size
    NUM_EPOCHS = opt.num_epochs
    sample_rate=16000
    serialized_train_folder = './data/serialized_train_data/' #

    # load data
    print('loading data...')
    train_dataset = AudioDataset(serialized_train_folder)
    train_data_loader = DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=False,num_workers=4,drop_last=False,collate_fn=my_collate) #加载数据  collate_fn设置拼接方式
    # generate reference batch
    ref_batch = train_dataset.reference_batch(12) #从测试数据中随机挑选一些数据用于计算统计参量
    idx=torch.tensor(random.sample(range(1, ref_batch.size(0)),64))
    ref_batch = torch.index_select(ref_batch, 0, idx)  # 在指定维度，根据索引号查找
    #len=ref_batch.size(0)
    #ref_batch=ref_batch[round(len/2),:,:]
    # create D and G instances
    discriminator = Discriminator() #创建生成器
    generator = Generator() #创建识别器
    #if torch.cuda.is_available():
    discriminator.to(device)
    generator.to(device)
    ref_batch = ref_batch.to(device)
    #ref_batch = Variable(ref_batch)
    print("# generator parameters:", sum(param.numel() for param in generator.parameters()))
    print("# discriminator parameters:", sum(param.numel() for param in discriminator.parameters()))
    # optimizers
    g_optimizer = optim.Adam(generator.parameters(), lr=0.0001) #参数优化  学习率是否可通过验证集进行调整？
    d_optimizer = optim.Adam(discriminator.parameters(), lr=0.0004) #lr=0.0001  0.00005

    for epoch in range(NUM_EPOCHS):#迭代
        train_bar = tqdm(train_data_loader)  #只需要封装任意的迭代器 tqdm(iterator).在一个epoch下，对一块一块数据进行训练
        for train_batch, train_clean, train_noisy in train_bar: #train_batch：torch.Size([18, 2, 16384])，train_noisy为合成的带噪音频
            # latent vector - normal distribution
            #GAN本来就是完成一个分布的配准变换，GAN的生成器就是把一个高斯分布（或者其他先验的随机分布）
            # 变换成目标数据分布，但一旦分布确定，就是固定的 ，但我们需要的是变化的高斯分布，此时就需要
            # 实际的带噪数据进行控制（把真实带噪数据拉到已知高斯分布上）这里实际是把输入的随机变量当成了
            # 数据的latent space。实际上也有一些工作在G之前加上另外一个变换网络T把数据的随机变量变换到数
            # 据表达的latent variable空间，然后再通过G生成数据，以保证系统在latent space具有更好的语义和操作性
            x = train_noisy
            le = train_noisy.size(0)
            # '''
            in1 = torch.unsqueeze(x[1, :, :], 0)
            in2 = torch.unsqueeze(x[le - 1, :, :], 0)
            x = torch.cat([in1, x], dim=0)
            train_noisy1 = torch.cat([x, in2], dim=0)
            # '''
            z = nn.init.normal_(torch.Tensor(train_batch.size(0), 256, 24))
            if torch.cuda.is_available():
                train_batch, train_clean, train_noisy, train_noisy1 = train_batch.to(device), train_clean.to(
                    device), train_noisy.to(device), train_noisy1.to(device)  # 数据送入设备
                z = z.to(device)
            #train_batch, train_clean, train_noisy = Variable(train_batch), Variable(train_clean), Variable(train_noisy)#和tensor差不多，搞成模型需要的数据格式
            #z = Variable(z)

            # TRAIN D to recognize clean audio as clean
            # training batch pass
            discriminator.zero_grad()#直接把模型的参数梯度设成0
            outputs = discriminator(train_batch, ref_batch) #ref_batch主要是对用于对每层数据进行规范化时候会用到
            clean_loss = torch.mean((outputs - 1.0) ** 2)  # L2 loss - we want them all to be 1  2017公式3前半部分
            clean_loss.backward()
            #print(clean_loss.item()) #用于调试

            # TRAIN D to recognize generated audio as noisy
            generated_outputs = generator(train_noisy1, z) #train_noisy1：1536
            outputs = discriminator(torch.cat((generated_outputs, train_noisy), dim=1), ref_batch) #按维数1拼接  train_noisy2：512
            noisy_loss = torch.mean(outputs ** 2)  # L2 loss - we want them all to be 0  2017公式3后半部分
            noisy_loss.backward()
            #可以将参看2018论文，重新随机选择一组train_batch  2.2计算公式的第三部分

            # d_loss = 0.5*clean_loss + 0.5*noisy_loss  #为何不是相加返回？应该这样是可以的
            d_optimizer.step()  # update parameters

            # TRAIN G so that D recognizes G(z) as real
            generator.zero_grad()
            generated_outputs = generator(train_noisy1, z)
            gen_noise_pair = torch.cat((generated_outputs, train_noisy), dim=1) #生成器G
            outputs = discriminator(gen_noise_pair, ref_batch) #判决器D
            g_loss_ = 0.5 * torch.mean((outputs - 1.0) ** 2) #2017公式5前半部分

            # L1 loss between generated output and clean sample
            l1_dist = torch.abs(torch.add(generated_outputs, torch.neg(train_clean)))#torch.neg对输入元素取负数。2017公式5后半部分
            g_cond_loss = 100 * torch.mean(l1_dist)  # conditional loss。100为λ
            g_loss = g_loss_ + g_cond_loss #公式5

            # backprop + optimize
            g_loss.backward()
            g_optimizer.step()

            train_bar.set_description(
                'Epoch {}: d_clean_loss {:.4f}, d_noisy_loss {:.4f}, g_loss {:.4f}, g_conditional_loss {:.4f}'
                    .format(epoch + 1, clean_loss.item(), noisy_loss.item(), g_loss.item(), g_cond_loss.item()))

        #if epoch%11==0:
            # save the model parameters for each epoch（不用每次迭代都保存模型参数）
            g_path = os.path.join('epochs', 'generator-{}.pkl'.format(epoch + 1))
            d_path = os.path.join('epochs', 'discriminator-{}.pkl'.format(epoch + 1))
            torch.save(generator.state_dict(), g_path)
            torch.save(discriminator.state_dict(), d_path)
