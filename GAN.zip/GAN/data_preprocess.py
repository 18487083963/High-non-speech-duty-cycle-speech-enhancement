import os
import torch
import librosa #注意：librosa.display模块并不默认包含在librosa中
import numpy as np
import h5py
from tqdm import tqdm

clean_train_wav = './data/clean_trainset/' #不加最后的斜杆就会出现反斜杠
noisy_train_wav = './data/noisy_trainset/'
clean_test_wav = './data/clean_testset/'
noisy_test_wav = './data/noisy_testset/'
serialized_train_folder = './data/test/' #serialized_train_data/' #

window_size1 = 4096  # about 1 second of samples 2 ** 14 =16384(ps:**表示次幂)
window_size2 = 4096  # about 1 second of samples 2 ** 14 =16384(ps:**表示次幂)
sample_rate = 16000

def slice_signal(wav, window_size, stride, sample_rate): #分帧
    #分帧
    #wav, _ = librosa.load(file, sr=sample_rate) #file是wav文件路径  为什么没法读Python路径下的wav？
    hop = int(window_size * stride)
    for end_idx in range(window_size, len(wav), hop): #并未加窗函数
        start_idx = end_idx - window_size
        slice_sig = wav[start_idx:end_idx]
        if start_idx == 0:
            slices=np.mat(slice_sig)
            continue
        slices = np.row_stack((slices,np.mat(slice_sig)))
    slices = torch.from_numpy(slices).type(torch.FloatTensor)
    return torch.unsqueeze(slices, dim=0).permute(1,0,2)

def process_and_serialize(data_type):
    #序列化、下采样切片信号并保存在单独的文件夹中
    stride1 = 1/2  #步长（占用总数的比例）
    stride2 = 1 / 3

    if not os.path.exists(serialized_train_folder):
        os.makedirs(serialized_train_folder)

    # walk through the path, slice the audio file, and save the serialized result
    for root, dirs, files in os.walk(clean_train_wav):
        if len(files) == 0:
            continue
        f = h5py.File('data.h5','w')   #创建一个h5文件，文件指针是f
        for filename in tqdm(files, desc='Serialize and down-sample {} audios'.format(data_type)):
            clean_file = os.path.join(clean_train_wav, filename)
            noisy_file = os.path.join(noisy_train_wav, filename)
            # 分别分帧
            clean_sliced = slice_signal(clean_file, window_size1, stride1, sample_rate) #分帧，50%重叠（转换为目标采样率再分帧，去掉非整数帧）
            noisy_sliced = slice_signal(noisy_file, window_size1, stride1, sample_rate)
            #train_sliced = slice_signal(noisy_file, window_size2, stride2, sample_rate) #用于送入generator的带噪音频
            #保存
            pairs=np.concatenate([clean_sliced,noisy_sliced],axis=1)
            pairs=torch.from_numpy(pairs).type(torch.FloatTensor)
            #f[filename.split('.')[0]]=pairs #读取相当麻烦
            np.save(os.path.join(serialized_train_folder, filename.split('.')[0]), arr=pairs)  # 文件名 _第几段
            #np.savez(os.path.join(serialized_train_folder, filename.split('.')[0]), train_batch=pairs,clean=clean_sliced,noisy=noisy_sliced)

if __name__ == '__main__':#将数据对都切割成16384个数据点保存成.npy格式用于训练
    process_and_serialize('train')
