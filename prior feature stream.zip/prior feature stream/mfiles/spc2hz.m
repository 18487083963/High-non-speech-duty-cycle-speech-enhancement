function hz=spc2hz(i,fs,n)
hz = i/((n-1)/(fs/2));