# SEGAN_CNN
1.A PyTorch implementation of SEGAN based on INTERSPEECH 2017 paper [SEGAN: Speech Enhancement Generative Adversarial Network](https://arxiv.org/abs/1703.09452).

2.Whispered-to-voiced Alaryngeal Speech Conversion with Generative Adversarial Networks 2018 paper

3.Speech Enhancement Using a Two-Stage Network for an Efficient Boosting Strategy

## Requirements
* pycharm
* PyTorch
* librosa
```
差什么包  pip install 安装就好了
```

## Datasets
The clear and noisy speech datasets are downloaded from [DataShare](https://datashare.is.ed.ac.uk/handle/10283/2791).
Download the `56kHZ` train datasets and test datasets, then extract them into `data` directory.

If you want using other datasets, you should change the path of data defined on `data_preprocess.py`.

自己合成带噪数据也不错（ps:根据自己需要和合成不同分贝带噪音频，采用率什么的都可以自己设定）

## Usage
### Data Pre-process
```
python data_preprocess.py
```
The pre-processed datas are on `data/serialized_train_data` and `data/serialized_test_data`.

### Train Model 
```
python main.py ----batch_size 4 --num_epochs 300
optional arguments:
--batch_size             train batch size [default value is 4]
--num_epochs             train epochs number [default value is 86]
ps:因为在一个文件里放了很多数据N，这里的batch_size其实是指的是加载的文件个数，最后得到的batch_sizes=batch_size*N
```
### Test 
```
python test_audio.py ----file_name pp.wav --epoch_name generator-80.pkl
optional arguments:
--file_name              audio file name
--epoch_name             generator epoch name
```
The generated enhanced audio is on the same directory of input audio.

## author:Mingliang YANG