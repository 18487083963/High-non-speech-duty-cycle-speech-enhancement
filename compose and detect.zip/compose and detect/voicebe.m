function [a,b]=voicebe(x)

count=0;%��¼ǰ�οհ׶�
le=length(x);
for j=1:le
    if x(j)<0.04
        count=count+1;
    else
        break
    end
end
if count>le*0.98  %ȫ��Ϊ�հ�
    a=1;
    b=1;
else
    lee=le;
    count1=0;%��¼ĩβ�Ŀհ׶�
    while(lee>0)
        if x(lee)<0.04
            count1=count1+1;
        else
            break
        end
        lee=lee-1;
    end
    if (count+count1)<0.98*le
        count2=le-count1;
        if count>0
            a=count+1;
        else
            a=1;
        end
        b=count2;
    else
        a=1;
        b=1;
    end
end