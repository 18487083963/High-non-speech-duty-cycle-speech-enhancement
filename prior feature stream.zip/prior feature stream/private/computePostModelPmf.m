function postModelPmf = computePostModelPmf(logMarginalLikelihood, ...
        logModelPrior)
    %�������PMF�� probability mass function��
    scaledLogPostModelPmf = logMarginalLikelihood + logModelPrior;
    scaledPostModelPmf = ...
        exp(scaledLogPostModelPmf-max(scaledLogPostModelPmf));
    postModelPmf = scaledPostModelPmf/sum(scaledPostModelPmf);
end
