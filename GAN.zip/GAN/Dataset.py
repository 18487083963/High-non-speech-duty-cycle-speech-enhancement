import os

import numpy as np
import torch
from torch.utils import data
from librosa.util import find_files
import torchvision.transforms as transforms


def emphasis(signal_batch, emph_coeff=0.95, pre=True):
    """
    Pre-emphasis or De-emphasis of higher frequencies given a batch of signal.

    Args:
        signal_batch: batch of signals, represented as numpy arrays
        emph_coeff: emphasis coefficient
        pre: pre-emphasis or de-emphasis signals

    Returns:
        result: pre-emphasized or de-emphasized signal batch
        # coding=utf-8

###### 欢迎使用脚本任务,让我们首选熟悉下一些使用规则吧 ######

# 数据集文件目录
datasets_prefix = '/root/paddlejob/workspace/train_data/datasets/'

# 数据集文件具体路径请在编辑项目状态下,通过左侧导航栏「数据集」中文件路径拷贝按钮获取
train_datasets =  '通过路径拷贝获取真实数据集文件路径 '

# 输出文件目录. 任务完成后平台会自动把该目录所有文件压缩为tar.gz包，用户可以通过「下载输出」可以将输出信息下载到本地.
output_dir = "/root/paddlejob/workspace/output"

# 日志记录. 任务会自动记录环境初始化日志、任务执行日志、错误日志、执行脚本中所有标准输出和标准出错流(例如print()),用户可以在「提交」任务后,通过「查看日志」追踪日志信息.
    """
    result = np.zeros(signal_batch.shape)
    for sample_idx, sample in enumerate(signal_batch):
        for ch, channel_data in enumerate(sample):
            if pre:
                result[sample_idx][ch] = np.append(channel_data[0], channel_data[1:] - emph_coeff * channel_data[:-1])
            else:
                result[sample_idx][ch] = np.append(channel_data[0], channel_data[1:] + emph_coeff * channel_data[:-1])
    return result

class AudioDataset(object):
    def __init__(self, file_path):
        if not os.path.exists(file_path):
            raise FileNotFoundError('The {} data folder does not exist!'.format(file_path))
        #self.filelist =find_files(file_path,'npz') #找到npz格式的文件  里面是音频数据？？  一个文件同时存放三个音频数据？？
        #xx=os.listdir(file_path)
        self.filelist = [os.path.join(file_path, filename) for filename in os.listdir(file_path)]
        #print(filelist)

    def reference_batch(self, batch_size):  # 这里随机挑选一些数据 batch_size=1就行了，因为一个batch里面就有很多数据了
        """
        Randomly selects a reference batch from dataset.
        Reference batch is used for calculating statistics for virtual batch normalization operation.
        Args:
            batch_size(int): batch size

        Returns:
            ref_batch: reference batch
        """
        ref_file_names = np.random.choice(self.filelist, batch_size)
        #ref_file_names = np.random.choice(self.file_names, batch_size)
        ref_batch = np.concatenate([np.load(f) for f in ref_file_names],axis=0)
        #ref_batch=np.random.choice(ref_batch,)
        ref_batch = emphasis(ref_batch, emph_coeff=0.95)
        return torch.from_numpy(ref_batch).type(torch.FloatTensor)

    def __getitem__(self, idx):
        pairs = np.load(self.filelist[idx])
        pairs = emphasis(pairs, emph_coeff=0.95)  # np.newaxis的功能是插入新维度 .这里进行预加重
        clean = pairs[:, 0, :]
        clean = clean[:, np.newaxis, :]
        noisy = pairs[:, 1, :]
        noisy = noisy[:, np.newaxis, :]
        #return pairs, clean, noisy # 1536长度的训练数据点torch.from_numpy(pairs).type(torch.FloatTensor)
        return torch.from_numpy(pairs).type(torch.FloatTensor), torch.from_numpy(clean).type(torch.FloatTensor),\
               torch.from_numpy(noisy).type(torch.FloatTensor) # 1536长度的训练数据点

    def __len__(self):
        return len(self.filelist)