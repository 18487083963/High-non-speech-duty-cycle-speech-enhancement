function [outprob,vadout]=vad(x,fs)
%%author��@������
%�������������������
% speech noise threshold
p1=0.1;
p2=20;
% set path
addpath mfiles/

% ---feature---
% GT
NbCh=64;
% Gabor
nb_mod_freq=2;
% LTSV
R=50; % context
M=10; % smoothing
ltsvThr=0.5;
ltsvSlope=0.2;
% vprob2 and ltsv2
K=30; order=4;
% ---vad model---
load('models/model.mat')
% ---visualize---
 %x=downsample(x(:,1),fs/8000);
% [1] extract cochleagram
gt=FE_GT(x,fs,NbCh);

% [2] Gabor filtering applied on mel
gbf=FE_GBF(x,fs,nb_mod_freq,false);
gbf= [gbf gbf(:,ones(1,10)*size(gbf,2))];
gbf = gbf(:,1:size(gt,2));

% [3] LTSV
ltsv=FE_LTSV(x,fs,R,M,gt,ltsvThr,ltsvSlope);
ltsv2 = convert_to_context_stream(ltsv, K, order);
ltsv2= [ltsv2 ltsv2(:,ones(1,10)*size(ltsv,2))];
ltsv2 = ltsv2(:,1:size(gt,2));

% [4] vprob prob
vprob=voicingfeature(x,fs);%����
vprob2 = convert_to_context_stream(vprob, K, order);
vprob2 = [vprob2 vprob2(:,ones(1,10)*size(vprob,2))];
vprob2 = vprob2(:,1:size(gt,2));

% feature for VAD
test_x = [gt;gbf;ltsv2;vprob2];
test_x_norm = mvn(test_x);

% VAD decoding
[~,~,output] = nntest(dnn, test_x_norm');
outprob=double(output(:,1));
vadout=medfilt1(outprob.^2,p2)>p1;
%  if visualize
%   imagesc(mvn(gt));axis xy;hold on;
%   plot(10*vadout,'m','LineWidth',3); zoom xon; hold off
%  end

