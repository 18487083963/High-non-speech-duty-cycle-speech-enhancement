import os
import numpy as np
import torch
import torch.nn as nn
import librosa

from scipy.io import wavfile
from torch.autograd import Variable
from tqdm import tqdm #tqdm(list)方法可以传入任意一种list,比如数组 , 可迭代对象长度为n，则进度条有n个进度

from data_preprocess import slice_signal, window_size2, sample_rate
from model import Generator
from Dataset import emphasis
#语音增强测试
if __name__ == '__main__':
    #EPOCH_NAME = '/generator-35.pkl' # 已训练好的模型参数
    #wav_root='./data/noisy_testset/' #测试数据
    #enhanced_dir='./data/enhanced/' #存放语音增强后的数据
    EPOCH_NAME = '/generator-114.pkl' # 已训练好的模型参数
    wav_root='./data/detected/' #测试数据
    enhanced_dir='./data/catch/' #存放语音增强后的数据
    speakers_dir = os.listdir(wav_root)

    generator = Generator()  #生成器
    generator.load_state_dict(torch.load('epochs/' + EPOCH_NAME, map_location='cpu')) #加载训练好的模型参数
    if torch.cuda.is_available():
        generator.cuda()
    enhanced_speech = []
    for i in range(len(speakers_dir)): #ps:这里测试程序只是方便试验测试，如果要应用还需要修改此处程序（以便于实时输出而不是一整段处理完了再输出）
        #wav_dir = wav_root + speakers_dir[i]
        wav_dir = os.path.join(wav_root + speakers_dir[i])
        '''
        noisy_slice = slice_signal(wav_dir, 4096, 1, sample_rate)
        # noisy_slicess.append(noisy_slices)
        #enhanced_speech = []
        z = nn.init.normal_(torch.Tensor(noisy_slice.size(0),512,8))  #
        #noisy_slice = torch.from_numpy(emphasis(noisy_slice[np.newaxis, np.newaxis, :])).type(torch.FloatTensor)
        if torch.cuda.is_available():
            noisy_slice, z = noisy_slice.cuda(), z.cuda()
        noisy_slice, z = Variable(noisy_slice), Variable(z)
        generated_speech = generator(noisy_slice, z).data.cpu().numpy()  # 把带噪音频和z送入CPU中
        generated_speech = emphasis(generated_speech, emph_coeff=0.95, pre=False)  # 预加重
        generated_speech = torch.from_numpy(generated_speech)
        generated_speech = generated_speech.reshape(-1).numpy()  #
        file_name = os.path.join(enhanced_dir, speakers_dir[i])
        wavfile.write(file_name, sample_rate, generated_speech.T)  # 保存语音增强后的信号
        print('第%d个测试音频已完成！'%(i))
        #'''

        wav, _ = librosa.load(wav_dir, sr=sample_rate)
        le = wav.size
        wav[0:300]=0
        wav[(le-200):le]=0
        count = 0  # 用于记录前段0值
        for k in range(le):
            if wav[k] == 0:
                count = count + 1
            else:
                wav = wav[count:le]
                break
        if count == le:
            lee = 0
            wav = np.zeros(1)
        else:
            lee = wav.size
        lee1 = lee
        count1 = 0  # 记录后端0值
        while (lee1 > 0):
            lee1 = lee1 - 1
            if wav[lee1] == 0:
                count1 = count1 + 1
            else:
                wav = wav[0:lee - count1]
                break
        step = int(0.5 * 4096)
        if wav.size > 4096+step:#用于保证两段以上
            noisy_slice = slice_signal(wav, 4096, 0.5, sample_rate)
            z = nn.init.normal_(torch.Tensor(noisy_slice.size(0), 512, 8))  #
            noisy_slice = torch.from_numpy(emphasis(noisy_slice)).type(torch.FloatTensor)
            if torch.cuda.is_available():
                noisy_slice, z = noisy_slice.cuda(), z.cuda()
            noisy_slice, z = Variable(noisy_slice), Variable(z)
            generated_speech = generator(noisy_slice, z).data.cpu().numpy()  # 把带噪音频和z送入CPU中
            generated_speech = emphasis(generated_speech, emph_coeff=0.95, pre=False)  # 预加重
            generated_speech = torch.from_numpy(generated_speech)
            generated_speech = generated_speech.squeeze()
            len = generated_speech.size(0)
        else:
            generated_speech = wav  # 如果语音段小于16384，直接不粗噪
            generated_speech = generated_speech.astype(np.float64)
            generated_speech = torch.from_numpy(generated_speech)
            len = 1
            # generated_speech=torch.unsqueeze(generated_speech,0)
        if len - 1 == 0:
            # generated_speech = generated_speech.squeeze()
            s1 = generated_speech
        else:
            for j in range(len - 1):
                if j == 0:
                    s1 = generated_speech[j, 0:step]
                    s2 = generated_speech[j, step:step * 2]
                    s3 = generated_speech[j + 1, 0:step]
                    s4 = (s3 + s2) / 2
                    s1 = torch.cat([s1, s4], dim=0)
                else:
                    s2 = generated_speech[j, step:step * 2]
                    s3 = generated_speech[j + 1, 0:step]
                    s4 = (s3 + s2) / 2
                    s1 = torch.cat([s1, s4], dim=0)
                    if j == len - 2:
                        s5 = generated_speech[j + 1, step:4096]
                        s1 = torch.cat([s1, s5], dim=0)
        #
        if count > 0:
            f = np.zeros(count)
            f = torch.from_numpy(f)
            if count == le:
                s1 = f
            else:
                s1 = torch.cat([f, s1], dim=0)
        if count1 > 0:
            b = np.zeros(count1)
            b = torch.from_numpy(b)
            s1 = torch.cat([s1, b], dim=0)
        #
        generated_speech = s1.reshape(-1).numpy()  #
        # ps：这里还需要增加卷积用于平滑吉布斯现象和补充失真信息
        # enhanced_speech.append(generated_speech)  #将分帧后的增强信号连起来
        # enhanced_speech = np.array(enhanced_speech).reshape(1, -1)
        file_name = os.path.join(enhanced_dir, speakers_dir[i])
        wavfile.write(file_name, sample_rate, generated_speech.T)  # 保存语音增强后的信号
        print('第%d个测试音频已完成！' % (i))
        # del noisy_slice
        # del generated_speech
    #'''