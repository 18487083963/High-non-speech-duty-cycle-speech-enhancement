import argparse
from torch import optim
from torch.utils.data import DataLoader
from tqdm import tqdm #Tqdm是一个快速，可扩展的python进度条，可以在python长循环中添加一个进度提示信息，用户只需要封装任意的迭代器tqdm(iterator)。
#数据处理
import os
import numpy as np
from librosa.util import find_files
##
import torch.nn as nn
import torch.nn.functional as F
import math
from torch.nn.modules import Module
from torch.nn.parameter import Parameter
import torch
import random
from torch.autograd import Variable


def emphasis(signal_batch, emph_coeff=0.95, pre=True):
    """
    Pre-emphasis or De-emphasis of higher frequencies given a batch of signal.

    Args:
        signal_batch: batch of signals, represented as numpy arrays
        emph_coeff: emphasis coefficient
        pre: pre-emphasis or de-emphasis signals

    Returns:
        result: pre-emphasized or de-emphasized signal batch
        # coding=utf-8

###### 欢迎使用脚本任务,让我们首选熟悉下一些使用规则吧 ######

# 数据集文件目录
datasets_prefix = '/root/paddlejob/workspace/train_data/datasets/'

# 数据集文件具体路径请在编辑项目状态下,通过左侧导航栏「数据集」中文件路径拷贝按钮获取
train_datasets =  '通过路径拷贝获取真实数据集文件路径 '

# 输出文件目录. 任务完成后平台会自动把该目录所有文件压缩为tar.gz包，用户可以通过「下载输出」可以将输出信息下载到本地.
output_dir = "/root/paddlejob/workspace/output"

# 日志记录. 任务会自动记录环境初始化日志、任务执行日志、错误日志、执行脚本中所有标准输出和标准出错流(例如print()),用户可以在「提交」任务后,通过「查看日志」追踪日志信息.
    """
    result = np.zeros(signal_batch.shape)
    for sample_idx, sample in enumerate(signal_batch):
        for ch, channel_data in enumerate(sample):
            if pre:
                result[sample_idx][ch] = np.append(channel_data[0], channel_data[1:] - emph_coeff * channel_data[:-1])
            else:
                result[sample_idx][ch] = np.append(channel_data[0], channel_data[1:] + emph_coeff * channel_data[:-1])
    return result

class AudioDataset(object):
    def __init__(self, file_path):
        if not os.path.exists(file_path):
            raise FileNotFoundError('The {} data folder does not exist!'.format(file_path))
        #self.filelist =find_files(file_path,'npz') #找到npz格式的文件  里面是音频数据？？  一个文件同时存放三个音频数据？？
        #xx=os.listdir(file_path)
        self.filelist = [os.path.join(file_path, filename) for filename in os.listdir(file_path)]
        #print(filelist)

    def reference_batch(self, batch_size):  # 这里随机挑选一些数据 batch_size=1就行了，因为一个batch里面就有很多数据了
        """
        Randomly selects a reference batch from dataset.
        Reference batch is used for calculating statistics for virtual batch normalization operation.
        Args:
            batch_size(int): batch size

        Returns:
            ref_batch: reference batch
        """
        ref_file_names = np.random.choice(self.filelist, batch_size)
        #ref_file_names = np.random.choice(self.file_names, batch_size)
        ref_batch = np.concatenate([np.load(f) for f in ref_file_names],axis=0)
        #ref_batch=np.random.choice(ref_batch,)
        ref_batch = emphasis(ref_batch, emph_coeff=0.95)
        return torch.from_numpy(ref_batch).type(torch.FloatTensor)

    def __getitem__(self, idx):
        pairs = np.load(self.filelist[idx])
        pairs = emphasis(pairs, emph_coeff=0.95)  # np.newaxis的功能是插入新维度 .这里进行预加重
        clean = pairs[:, 0, :]
        clean = clean[:, np.newaxis, :]
        noisy = pairs[:, 1, :]
        noisy = noisy[:, np.newaxis, :]
        #return pairs, clean, noisy # 1536长度的训练数据点torch.from_numpy(pairs).type(torch.FloatTensor)
        return torch.from_numpy(pairs).type(torch.FloatTensor), torch.from_numpy(clean).type(torch.FloatTensor),\
               torch.from_numpy(noisy).type(torch.FloatTensor) # 1536长度的训练数据点

    def __len__(self):
        return len(self.filelist)

class VirtualBatchNorm1d(Module):
    """
    Module for Virtual Batch Normalization.
    和普通的数据标准化类似, 是将分散的数据统一的一种做法，让机器学习更容易学习到数据之中的规律
    （每层网络之前都进行这样处理，避免激活函数失效），这样的处理层也可以看做单独的层（扩展参数 gamma,和平移参数beta,就是这层里面的参数，并且也是存在反馈的），
    Implementation borrowed and modified from Rafael_Valle's code + help of SimonW from this discussion thread:
    https://discuss.pytorch.org/t/parameter-grad-of-conv-weight-is-none-after-virtual-batch-normalization/9036
    """

    def __init__(self, num_features, eps=1e-5):
        super().__init__()
        # batch statistics
        self.num_features = num_features
        self.eps = eps  # epsilon
        # define gamma and beta parameters
        gamma = torch.normal(mean=torch.ones(1, num_features, 1), std=0.02)
        self.gamma = Parameter(gamma.float())  # (gamma.float().cuda(async=True))
        self.beta = Parameter(torch.FloatTensor(1,num_features,1).fill_(0))
        #self.gamma = Parameter(torch.normal(means=torch.ones(1, num_features, 1), std=0.02))
        #self.beta = Parameter(torch.zeros(1, num_features, 1))

    def get_stats(self, x): #计算块的均值和方差
        """
        Calculates mean and mean square for given batch x.
        Args:
            x: tensor containing batch of activations
        Returns:
            mean: mean tensor over features
            mean_sq: squared mean tensor over features
        """
        mean = x.mean(2, keepdim=True).mean(0, keepdim=True)
        mean_sq = (x ** 2).mean(2, keepdim=True).mean(0, keepdim=True)
        return mean, mean_sq

    def forward(self, x, ref_mean, ref_mean_sq): #更新均值和方差（因为数据量很大时候无法一下子计算所有的均值和方差）
        """
        Forward pass of virtual batch normalization.
        Virtual batch normalization require two forward passes
        for reference batch and train batch, respectively.

        Args:
            x: input tensor
            ref_mean: reference mean tensor over features
            ref_mean_sq: reference squared mean tensor over features
        Result:
            x: normalized batch tensor
            ref_mean: reference mean tensor over features
            ref_mean_sq: reference squared mean tensor over features
        """
        mean, mean_sq = self.get_stats(x)
        if ref_mean is None or ref_mean_sq is None:
            # reference mode - works just like batch norm
            mean = mean.clone().detach()
            mean_sq = mean_sq.clone().detach()
            out = self.normalize(x, mean, mean_sq)
        else:
            # calculate new mean and mean_sq
            batch_size = x.size(0)
            new_coeff = 1. / (batch_size + 1.)
            old_coeff = 1. - new_coeff
            mean = new_coeff * mean + old_coeff * ref_mean
            mean_sq = new_coeff * mean_sq + old_coeff * ref_mean_sq
            out = self.normalize(x, mean, mean_sq)
        return out, mean, mean_sq

    def normalize(self, x, mean, mean_sq):  #数据规范化（用到均值和方差）
        """
        Normalize tensor x given the statistics.

        Args:
            x: input tensor
            mean: mean over features
            mean_sq: squared means over features

        Result:
            x: normalized batch tensor
        """
        assert mean_sq is not None #断言语句
        assert mean is not None
        assert len(x.size()) == 3  # specific for 1d VBN
        if mean.size(1) != self.num_features:
            raise Exception('Mean tensor size not equal to number of features : given {}, expected {}'
                            .format(mean.size(1), self.num_features))
        if mean_sq.size(1) != self.num_features:
            raise Exception('Squared mean tensor size not equal to number of features : given {}, expected {}'
                            .format(mean_sq.size(1), self.num_features))

        std = torch.sqrt(self.eps + mean_sq - mean ** 2)
        x = x - mean
        x = x / std
        x = x * self.gamma
        x = x + self.beta
        return x

    def __repr__(self):
        return ('{name}(num_features={num_features}, eps={eps}'
                .format(name=self.__class__.__name__, **self.__dict__))

class GSkip(Module):  #计算跳转连接部分
    #def __init__(self, skip_type='alpha',size,skip_init='one', skip_dropout=0,kwidth=5, bias=True): #初始化
    def __init__(self, skip_type, size, skip_init, skip_dropout=0, kwidth=5, bias=True): #初始化
        # skip_init only applies to alpha skips
        super().__init__()
        if skip_type == 'alpha' or skip_type == 'constant':
            if skip_init == 'zero':
                alpha_ = torch.zeros(size)
            elif skip_init == 'randn':  #随机初始化跳转连接
                alpha_ = torch.randn(size)
            elif skip_init == 'one':
                alpha_ = torch.ones(size)
            else:
                raise TypeError('Unrecognized alpha init scheme: ',
                                skip_init)
            #if cuda:
            #    alpha_ = alpha_.cuda()
            if skip_type == 'alpha':
                self.skip_k = nn.Parameter(alpha_.view(1, -1, 1))
            else:
                # constant, not learnable
                self.skip_k = nn.Parameter(alpha_.view(1, -1, 1))
                self.skip_k.requires_grad = False
        elif skip_type == 'conv':
            if kwidth > 1:
                pad = kwidth // 2
            else:
                pad = 0
            self.skip_k = nn.Conv1d(size, size, kwidth, stride=1,
                                    padding=pad, bias=bias)
        else:
            raise TypeError('Unrecognized GSkip scheme: ', skip_type)
        self.skip_type = skip_type
        if skip_dropout > 0:
            self.skip_dropout = nn.Dropout(skip_dropout)

    def forward(self, hj):
        if self.skip_type == 'conv': #根据选着的跳转连接方式更新
            sk_h = self.skip_k(hj)  #这个才是真正的跳转连接
        else: #否者采用默认方式
            skip_k = self.skip_k.repeat(hj.size(0), 1, hj.size(2))
            sk_h =  skip_k * hj
        if hasattr(self, 'skip_dropout'):
            sk_h = self.skip_dropout(sk_h)
        return sk_h

class TDNN(nn.Module):
    def __init__(self, context, input_dim, output_dim, full_context = True):
        super(TDNN,self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.check_valid_context(context) #有效范围
        self.kernel_width, context = self.get_kernel_width(context,full_context)  #核宽度
        self.register_buffer('context',torch.LongTensor(context))
        self.full_context = full_context
        stdv = 1./math.sqrt(input_dim)
        self.kernel = nn.Parameter(torch.Tensor(output_dim, input_dim,self.kernel_width).normal_(0,stdv))
        self.bias = nn.Parameter(torch.Tensor(output_dim).normal_(0,stdv))
        # self.cuda_flag = False

    def forward(self,x):
        # Check if parameters are cuda type and change context
        # if type(self.bias.data) == torch.cuda.FloatTensor and self.cuda_flag == False:
        #     self.context = self.context.cuda()
        #     self.cuda_flag = True
        conv_out = self.special_convolution(x, self.kernel, self.context, self.bias)
        return conv_out

    def special_convolution(self, x, kernel, context, bias):
        input_size = x.size()
        assert len(input_size) == 3, 'Input tensor dimensionality is incorrect. Should be a 3D tensor' #断言语句，如果不是，则报错。
        [batch_size,channel,input_sequence_length] = input_size
        # Allocate memory for output
        valid_steps = self.get_valid_steps(self.context, batch_size)  #做延时后的帧数目
        device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
        # Perform the convolution with relevant input frames
        for c, i in enumerate(valid_steps):
            features = torch.index_select(x, 0, context+i)#在指定维度，根据索引号查找
            features=features.view(1,features.size(0),-1)#维度变换
            xs = F.conv1d(features, kernel, bias = bias,padding=1)
            if i==2:
                y=xs
            else:
                y=torch.cat([y,xs],dim=0)
        y = y.to(device)
        return y

    @staticmethod   #统计方法（池化）
    def check_valid_context(context): #检查context是否合理
        # here context is still a list
        assert context[0] <= context[-1], 'Input tensor dimensionality is incorrect. Should be a 3D tensor'

    @staticmethod
    def get_kernel_width(context, full_context):
        if full_context:
            context = range(context[0],context[-1]+1) #确定一个context的范围
        return len(context), context

    @staticmethod
    def get_valid_steps(context, batch_size): #确定给定长度的序列，卷积之后的长度
        start = 0 if context[0] >= 0 else -1*context[0]
        end = batch_size if context[-1] <= 0 else batch_size - context[-1]
        return range(start, end)

class Generator(nn.Module):
    """G"""
    def __init__(self):
        super().__init__()
        #TDNN网络
        context = [[-2, 0]]
        #node_num = [1, 1]#channel：1-->3-->1
        full_context = [True, True]
        self.tdnn1 = TDNN(context[0], 3, 1, full_context[0]) #
        self.batch_norm1 = nn.BatchNorm1d(1)  #批规范化，避免经过网络层运算之后的分布出现变动。Internal Covariate Shift
        self.td_n1=nn.ReLU()
        #self.fc1 = nn.Linear(1, 4096)

        # encoder gets a noisy signal as input [B x 1 x 16384]
        self.enc1 = nn.Conv1d(in_channels=1, out_channels=64, kernel_size=31, stride=4, padding=15)  # [B x 16 x 8192]
        self.enc1_nl = nn.PReLU()
        self.enc2 = nn.Conv1d(64, 128,31, 4, 15)  # [B x 32 x 2048]
        self.enc2_nl = nn.PReLU()
        self.enc3 = nn.Conv1d(128, 256,31, 4, 15)  # [B x 64 x 1024]
        self.enc3_nl = nn.PReLU()
        self.enc4 = nn.Conv1d(256, 512,31, 4, 15)  # [B x 64 x 1024]
        self.enc4_nl = nn.PReLU()
        #'''
        #初始化跳转连接系数
        self.gskip3 = GSkip(skip_type = 'alpha', size=256, skip_init = 'one', skip_dropout = 0, kwidth = 15, bias = True) # 初始化
        self.gskip2 = GSkip(skip_type='alpha', size=128, skip_init='one', skip_dropout=0, kwidth=15, bias=True)  # 初始化
        self.gskip1 = GSkip(skip_type='alpha', size=64, skip_init='one', skip_dropout=0, kwidth=15, bias=True)  # 初始化
        #'''
        # decoder generates an enhanced signal
        # each decoder output are concatenated with homologous encoder output,
        # so the feature map sizes are doubled
        self.dec3 = nn.ConvTranspose1d(in_channels=1024, out_channels=256, kernel_size=31, stride=4, padding=15,output_padding=3) #逆卷积
        self.dec3_nl = nn.PReLU()
        self.dec2 = nn.ConvTranspose1d(512, 128, 31, 4, 15,3)  # [B x 64 x 1024]
        self.dec2_nl = nn.PReLU()
        self.dec1 = nn.ConvTranspose1d(256, 64, 31, 4, 15,3)  # [B x 32 x 2048]
        self.dec1_nl = nn.PReLU()
        self.dec_final = nn.ConvTranspose1d(128, 1,31, 4, 15,3)  # [B x 1 x 16384]
        self.dec_tanh = nn.Tanh()
        # initialize weights
        self.init_weights()  #因为所有数据都是送入cuda中，所以初始权值也应该在cuda中


    def init_weights(self):
        """
        Initialize weights for convolution layers using Xavier initialization.
        """
        for m in self.modules():
            if isinstance(m, nn.Conv1d) or isinstance(m, nn.ConvTranspose1d):
                nn.init.xavier_normal_(m.weight.data)#nn.init.xavier_normal(m.weight.data)

    def forward(self, x, z):
        """
        Forward pass of generator.

        Args:
            x: input batch (signal)
            z: latent vector
        """
        #tiem delay
        '''
        #首尾帧补充
        le = x.size(0)
        in1 = torch.unsqueeze(x[1, :, :], 0)
        in2 = torch.unsqueeze(x[le - 1, :, :], 0)
        x = torch.cat([in1, x], dim=0)
        x = torch.cat([x, in2], dim=0)
        '''
        a1 = self.batch_norm1(self.tdnn1(x))  # 激活函数为relu
        a1=self.td_n1(a1)
        #a2=self.fc1(a1)
        # encoding step
        e1 = self.enc1(a1)
        e2 = self.enc2(self.enc1_nl(e1))
        e3 = self.enc3(self.enc2_nl(e2))
        e4 = self.enc4(self.enc3_nl(e3))
        # c = compressed feature, the 'thought vector'
        c=self.enc4_nl(e4)
        # concatenate the thought vector with latent variable
        encoded = torch.cat((c, z), dim=1)

        # decoding step
        #d5 = self.dec5(encoded)
        # dx_c : concatenated with skip-connected layer's output & passed nonlinear layer
        #e5== self.gskip5(e5)
        #d5_c = self.dec5_nl(torch.cat((d5, self.gskip5(e5)), dim=1))
        d3 = self.dec3(encoded)
        d3_c = self.dec3_nl(torch.cat((d3, self.gskip3(e3)), dim=1))
        d2 = self.dec2(d3_c)
        d2_c = self.dec2_nl(torch.cat((d2, self.gskip2(e2)), dim=1))
        d1 = self.dec1(d2_c)
        d1_c = self.dec1_nl(torch.cat((d1, self.gskip1(e1)), dim=1))
        out = self.dec_tanh(self.dec_final(d1_c)) #torch.Size([18, 1, 1536])
        #for i in range(out.size(0) - 2):
         #   out1 = out[i, :, :]  # 两个张量（tensor）拼接在一起 注意是i+3,其实是到i+2
        return out

class Discriminator(nn.Module):
    """D：网络结构框架"""

    def __init__(self):
        super().__init__()
        # D gets a noisy signal and clear signal as input [B x 2 x 16384]
        negative_slope = 0.03
        self.conv1 = nn.Conv1d(in_channels=2, out_channels=64, kernel_size=31, stride=4, padding=15)  # [B x 32 x 8192]
        self.vbn1 = VirtualBatchNorm1d(64) #在网络层数据送出到激活函数之间进行Batch normalization .或许可以用SELU
        self.lrelu1 = nn.LeakyReLU(negative_slope)
        self.conv2 = nn.Conv1d(64, 128, 31, 4, 15)  # [B x 64 x 4096]
        self.vbn2 = VirtualBatchNorm1d(128)
        self.lrelu2 = nn.LeakyReLU(negative_slope)
        self.conv3 = nn.Conv1d(128, 256, 31, 4, 15)  # [B x 64 x 2048]
        self.dropout1 = nn.Dropout()#主要作用就是为了防止模型过拟合。
        self.vbn3 = VirtualBatchNorm1d(256)
        self.lrelu3 = nn.LeakyReLU(negative_slope)
        self.conv4 = nn.Conv1d(256, 512, 31, 4, 15)  # [B x 128 x 1024]
        self.vbn4 = VirtualBatchNorm1d(512)
        self.lrelu4 = nn.LeakyReLU(negative_slope)
        # 1x1 size kernel for dimension and parameter reduction
        self.conv_final = nn.Conv1d(512, 1, kernel_size=1, stride=1)  # [B x 1 x 8]
        self.lrelu_final = nn.LeakyReLU(negative_slope)
        self.fully_connected = nn.Linear(in_features=16, out_features=1)  # [B x 1]
        self.sigmoid = nn.Sigmoid()

        # initialize weights
        self.init_weights()

    def init_weights(self):
        """
        Initialize weights for convolution layers using Xavier initialization.
        """
        for m in self.modules():
            if isinstance(m, nn.Conv1d):
                nn.init.xavier_normal_(m.weight.data)

    def forward(self, x, ref_x): #层级运算
        """
        Forward pass of discriminator.

        Args:
            x: input batch (signal)
            ref_x: reference input batch for virtual batch norm
        """
        # reference pass
        ref_x = self.conv1(ref_x) #torch.Size([10, 32, 768])
        ref_x, mean1, meansq1 = self.vbn1(ref_x, None, None)
        ref_x = self.lrelu1(ref_x)
        ref_x = self.conv2(ref_x)
        ref_x, mean2, meansq2 = self.vbn2(ref_x, None, None)
        ref_x = self.lrelu2(ref_x)
        ref_x = self.conv3(ref_x)
        ref_x = self.dropout1(ref_x)
        ref_x, mean3, meansq3 = self.vbn3(ref_x, None, None)
        ref_x = self.lrelu3(ref_x)
        ref_x = self.conv4(ref_x)
        ref_x, mean4, meansq4 = self.vbn4(ref_x, None, None)
        ref_x = self.lrelu4(ref_x)
        # further pass no longer needed

        # train pass
        x = self.conv1(x)
        x, _, _ = self.vbn1(x, mean1, meansq1)#在网络层数据送出到激活函数之间进行Batch normalization
        x = self.lrelu1(x)
        x = self.conv2(x)
        x, _, _ = self.vbn2(x, mean2, meansq2)
        x = self.lrelu2(x)
        x = self.conv3(x)
        x = self.dropout1(x)
        x, _, _ = self.vbn3(x, mean3, meansq3)
        x = self.lrelu3(x)
        x = self.conv4(x)
        x, _, _ = self.vbn4(x, mean4, meansq4)
        x = self.lrelu4(x)
        x = self.conv_final(x)
        x = self.lrelu_final(x)
        # reduce down to a scalar value
        x = torch.squeeze(x)
        x = self.fully_connected(x)
        return self.sigmoid(x)  #是否应该更换其他的激活函数

def my_collate(batch): #DataLoader自定义的拼接方式
    for i, inputs in enumerate(batch):
        for j, inputss in enumerate(inputs):
            if i==0:
                if j==0:
                    train_batch=inputss
                elif j==1:
                    clean=inputss
                else:
                    noisy=inputss

            else:
                if j==0:
                    train_batch=torch.cat([train_batch,inputss],dim=0)
                elif j==1:
                    clean=torch.cat([clean,inputss],dim=0)
                else:
                    noisy=torch.cat([noisy,inputss],dim=0)

    return train_batch,clean,noisy
    #'''#

if __name__ == '__main__':
    #去掉跳转连接试试
    parser = argparse.ArgumentParser(description='Train Audio Enhancement')
    parser.add_argument('--batch_size', default=2, type=int, help='train batch size') #一个文件里存放了很多分帧数据即一个batch其实是包含很多数据的
    parser.add_argument('--num_epochs', default=100, type=int, help='train epochs number')
    #device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu") #检查pytorch是否是GPU版本
    device=torch.device("cpu")

    opt = parser.parse_args()
    BATCH_SIZE = opt.batch_size
    NUM_EPOCHS = opt.num_epochs
    sample_rate=16000
    serialized_train_folder = './data/serialized_train_data/' #

    # load data
    print('loading data...')
    train_dataset = AudioDataset(serialized_train_folder)
    train_data_loader = DataLoader(dataset=train_dataset, batch_size=BATCH_SIZE, shuffle=False,num_workers=4,drop_last=False,collate_fn=my_collate) #加载数据  collate_fn设置拼接方式
    # generate reference batch
    ref_batch = train_dataset.reference_batch(12) #从测试数据中随机挑选一些数据用于计算统计参量
    idx=torch.tensor(random.sample(range(1, ref_batch.size(0)),64))
    ref_batch = torch.index_select(ref_batch, 0, idx)  # 在指定维度，根据索引号查找
    #len=ref_batch.size(0)
    #ref_batch=ref_batch[round(len/2),:,:]
    # create D and G instances
    discriminator = Discriminator() #创建生成器
    generator = Generator() #创建识别器
    #if torch.cuda.is_available():
    discriminator.to(device)
    generator.to(device)
    ref_batch = ref_batch.to(device)
    #ref_batch = Variable(ref_batch)
    print("# generator parameters:", sum(param.numel() for param in generator.parameters()))
    print("# discriminator parameters:", sum(param.numel() for param in discriminator.parameters()))
    # optimizers
    g_optimizer = optim.Adam(generator.parameters(), lr=0.0001) #参数优化  学习率是否可通过验证集进行调整？
    d_optimizer = optim.Adam(discriminator.parameters(), lr=0.0004) #lr=0.0001  0.00005

    for epoch in range(NUM_EPOCHS):#迭代
        train_bar = tqdm(train_data_loader)  #只需要封装任意的迭代器 tqdm(iterator).在一个epoch下，对一块一块数据进行训练
        for train_batch, train_clean, train_noisy in train_bar: #train_batch：torch.Size([18, 2, 16384])，train_noisy为合成的带噪音频
            # latent vector - normal distribution
            #GAN本来就是完成一个分布的配准变换，GAN的生成器就是把一个高斯分布（或者其他先验的随机分布）
            # 变换成目标数据分布，但一旦分布确定，就是固定的 ，但我们需要的是变化的高斯分布，此时就需要
            # 实际的带噪数据进行控制（把真实带噪数据拉到已知高斯分布上）这里实际是把输入的随机变量当成了
            # 数据的latent space。实际上也有一些工作在G之前加上另外一个变换网络T把数据的随机变量变换到数
            # 据表达的latent variable空间，然后再通过G生成数据，以保证系统在latent space具有更好的语义和操作性
            x = train_noisy
            le = train_noisy.size(0)
            # '''
            in1 = torch.unsqueeze(x[1, :, :], 0)
            in2 = torch.unsqueeze(x[le - 1, :, :], 0)
            x = torch.cat([in1, x], dim=0)
            train_noisy1 = torch.cat([x, in2], dim=0)
            # '''
            z = nn.init.normal_(torch.Tensor(train_batch.size(0), 512, 8))
            if torch.cuda.is_available():
                train_batch, train_clean, train_noisy, train_noisy1 = train_batch.to(device), train_clean.to(
                    device), train_noisy.to(device), train_noisy1.to(device)  # 数据送入设备
                z = z.to(device)
            #train_batch, train_clean, train_noisy = Variable(train_batch), Variable(train_clean), Variable(train_noisy)#和tensor差不多，搞成模型需要的数据格式
            #z = Variable(z)

            # TRAIN D to recognize clean audio as clean
            # training batch pass
            discriminator.zero_grad()#直接把模型的参数梯度设成0
            outputs = discriminator(train_batch, ref_batch) #ref_batch主要是对用于对每层数据进行规范化时候会用到
            clean_loss = torch.mean((outputs - 1.0) ** 2)  # L2 loss - we want them all to be 1  2017公式3前半部分
            clean_loss.backward()
            #print(clean_loss.item()) #用于调试

            # TRAIN D to recognize generated audio as noisy
            generated_outputs = generator(train_noisy1, z) #train_noisy1：1536
            outputs = discriminator(torch.cat((generated_outputs, train_noisy), dim=1), ref_batch) #按维数1拼接  train_noisy2：512
            noisy_loss = torch.mean(outputs ** 2)  # L2 loss - we want them all to be 0  2017公式3后半部分
            noisy_loss.backward()
            #可以将参看2018论文，重新随机选择一组train_batch  2.2计算公式的第三部分

            # d_loss = 0.5*clean_loss + 0.5*noisy_loss  #为何不是相加返回？应该这样是可以的
            d_optimizer.step()  # update parameters

            # TRAIN G so that D recognizes G(z) as real
            generator.zero_grad()
            generated_outputs = generator(train_noisy1, z)
            gen_noise_pair = torch.cat((generated_outputs, train_noisy), dim=1) #生成器G
            outputs = discriminator(gen_noise_pair, ref_batch) #判决器D
            g_loss_ = 0.5 * torch.mean((outputs - 1.0) ** 2) #2017公式5前半部分

            # L1 loss between generated output and clean sample
            l1_dist = torch.abs(torch.add(generated_outputs, torch.neg(train_clean)))#torch.neg对输入元素取负数。2017公式5后半部分
            g_cond_loss = 100 * torch.mean(l1_dist)  # conditional loss。100为λ
            g_loss = g_loss_ + g_cond_loss #公式5

            # backprop + optimize
            g_loss.backward()
            g_optimizer.step()

            train_bar.set_description(
                'Epoch {}: d_clean_loss {:.4f}, d_noisy_loss {:.4f}, g_loss {:.4f}, g_conditional_loss {:.4f}'
                    .format(epoch + 1, clean_loss.item(), noisy_loss.item(), g_loss.item(), g_cond_loss.item()))

        #if epoch%11==0:
            # save the model parameters for each epoch（不用每次迭代都保存模型参数）
            g_path = os.path.join('epochs', 'generator-{}.pkl'.format(epoch + 1))
            d_path = os.path.join('epochs', 'discriminator-{}.pkl'.format(epoch + 1))
            torch.save(generator.state_dict(), g_path)
            torch.save(discriminator.state_dict(), d_path)
