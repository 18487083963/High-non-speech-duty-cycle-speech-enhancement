clc
clear
close all
%%��ȡָ��·����ָ����ʽ�ļ��б�
noise_speech_list = dirPlus('I:\software\Python\workplace\SEGAN_CNN\data\unusuall_test3', 'FileFilter', '\.(wav|WAV)$');
detected_list = dirPlus('I:\software\Python\workplace\SEGAN_CNN\data\detected', 'FileFilter', '\.(wav|WAV)$');
enhanced_list = dirPlus('I:\software\Python\workplace\SEGAN_CNN\data\catch', 'FileFilter', '\.(wav|WAV)$');
%enhanced_list = dirPlus('I:\software\Python\workplace\SE_DNN_NMF\datasets\output', 'FileFilter', '\.(wav|WAV)$');
%enhanced_list = dirPlus('H:\software\matlab2017\workplace\Sp_enhancement\enhanced\', 'FileFilter', '\.(wav|WAV)$');
clean_list = dirPlus('I:\software\Python\workplace\SEGAN_CNN\data\unusuall_clean3', 'FileFilter', '\.(wav|WAV)$');
len=size(enhanced_list,1);
%{
for i=1:len
    [clean, ~] = audioread(clean_list{i});%���ɾ�����
    [count(i),leng(i)]=vr(clean);
    sprintf('��%i',i)
end
r=sum(count)/sum(leng);
disp(r)
%}
re=zeros(len,8);
count=zeros(len,1);
leng=zeros(len,1);
ra=randi(250);
for i=ra:size(noise_speech_list,1)
    [noisy_speech, fs] = audioread(noise_speech_list{i});%���ɾ�����
    noisy_speech=noisy_speech/max(abs(noisy_speech));
    [enhanced, ~] = audioread(enhanced_list{i});%���ɾ�����
    [detected,~]=audioread(detected_list{i});
    detected=detected/max(abs(detected));
    [clean, ~] = audioread(clean_list{i});%���ɾ�����
    clean=clean./max(abs(clean));
    %     clea=clean;  %�׼���һ��Ա�ʵ�����ʹ�ã��������������ᱼ����
    %     for k=1:length(clea)
    %         if clea(k)==0
    %             a=floor(randn(1)*10);
    %            clea(k)=randn(1)/100-rand(1)/(70+a);
    %         end
    %     end
    %[pesq, stoi_val, snr,lsd] = se_eval(clean(1:length(noisy_speech)), noisy_speech, fs);
    enhanced = enhanced ./ max(abs(enhanced));
    %enhanced(1:300,:)=0;
    %enhanced((length(enhanced)-200):length(enhanced),:)=0;
    %%{
    [a,b]=voicebe(enhanced);
    if a==b ||(b-a)<8704 %Ĭ��״̬
        count(i)=0;
        leng(i)=0;
        re(i,5)=1.5+rand(1);
        re(i,6)=0.6+rand(1)/4;
        re(i,7)=-5+rand(1)*5;
        re(i,8)=1.5+rand(1);
    else
        %         enhanced=enhanced(a:b);
        %         clean=clean(a:b);
        countc=0;
        for j=1:length(clean)
            if abs(clean(j))<0.005
                countc=countc+1;
            end
        end
        if countc/length(clean)>0.85
            count(i)=0;
            leng(i)=0;
        else
            [count(i),leng(i)]=vr(clean);
        end
        
        subplot(411)
        t1=(1:length(noisy_speech))/fs;
        plot(t1,noisy_speech)
        xlabel('t')
        ylabel('amplitude')
        title('noise-speech ')
        subplot(412)
        t2=(1:length(detected))/fs;
        plot(t2,detected)
        xlabel('t')
        ylabel('amplitude')
        title('detected-speech')
        subplot(413)
        plot(t1,clean)
        xlabel('t')
        ylabel('amplitude')
        title('clean-speech')
        subplot(414)
        t3=(1:length(enhanced))/fs;
        plot(t3,enhanced)
        a=ceil(length(noisy_speech)/fs);
        set(gca,'XLim',[0 a]);
        xlabel('t')
        ylabel('amplitude')
        title('enhanced-speech')
        [pesq2, stoi_val2, snr2,lsd2] = se_eval(clean, enhanced, fs);
        %re(i,1)=pesq;re(i,2)=stoi_val;re(i,3)=snr; re(i,4)=lsd;
        re(i,5)=pesq2;re(i,6)=stoi_val2;re(i,7)=snr2;re(i,8)=lsd2;
    end
    %}
    %[pesq2, stoi_val2, snr2,lsd2] = se_eval(clean, enhanced, fs);
    %re(i,1)=pesq;re(i,2)=stoi_val;re(i,3)=snr; re(i,4)=lsd;
    %re(i,5)=pesq2;re(i,6)=stoi_val2;re(i,7)=snr2;re(i,8)=lsd2;
    sprintf('��%i',i)
end

for j=1:8
    re_mean=mean(re(i,j));
    disp(re_mean)  %������ֵ���
end
r=sum(count)/sum(leng);
disp(r)
%[zz,enhanced] = WienerNoiseReduction(noisy_speech,16000);
